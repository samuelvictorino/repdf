import React, { useRef, useCallback, useState, useEffect } from 'react';
import { useAppContext } from './context/AppContext';
import { loadPdfFromFiles, getPageAsBase64 } from './services/pdfService';
import { runClientOcr } from './services/geminiService';
import { ICONS } from './constants';
import PageGrid from './components/PageGrid';
import ModalManager from './components/ModalManager';
import { Notification } from './types';
import EmptyWorkspace from './components/EmptyWorkspace';

const NotificationsPopover = ({ notifications, onClear, onClose }: { notifications: Notification[], onClear: () => void, onClose: () => void }) => {
    const getIcon = (type: Notification['type']) => {
        switch (type) {
            case 'success': return <span className="text-green-500">{ICONS.check}</span>;
            case 'error': return <span className="text-red-500">{ICONS.close}</span>;
            case 'info': return <span className="text-blue-500">{ICONS.logo}</span>;
        }
    };
    
    return (
        <div className="fixed top-16 right-4 z-50">
            <div className="w-80 bg-white dark:bg-gray-800 rounded-lg shadow-2xl border border-gray-200 dark:border-gray-700 animate-modal-show origin-top-right">
                <div className="flex items-center justify-between p-3 border-b border-gray-200 dark:border-gray-700">
                    <h3 className="font-semibold">Notifications</h3>
                    <button onClick={onClear} className="text-sm text-accent-600 dark:text-accent-400 hover:underline">Clear all</button>
                </div>
                <div className="max-h-96 overflow-y-auto">
                    {notifications.length === 0 ? (
                        <p className="text-center text-gray-500 p-6">No new notifications.</p>
                    ) : (
                        <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                            {notifications.map(n => (
                                <li key={n.id} className="p-3 flex items-start space-x-3">
                                    <div className="w-5 h-5 flex-shrink-0 mt-0.5">{getIcon(n.type)}</div>
                                    <div>
                                        <p className="text-sm">{n.message}</p>
                                        <p className="text-xs text-gray-400">{new Date(n.timestamp).toLocaleTimeString()}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};

const Header = () => {
  const { state, dispatch } = useAppContext();
  const { past, future } = state.undoableState;
  const { notifications, importLoading } = state.uiState;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;

  const handleOpenClick = () => fileInputRef.current?.click();

  const handleFileChange = useCallback(async (filesToLoad: FileList | null) => {
    if (filesToLoad && filesToLoad.length > 0) {
      dispatch({ type: 'SET_IMPORT_LOADING', payload: true });
      dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'info', message: `Loading ${filesToLoad.length} file(s)...` } });
      try {
        const { files, pages, loadedDocs } = await loadPdfFromFiles(Array.from(filesToLoad));
        dispatch({ type: 'ADD_FILES', payload: { files, pages, loadedDocs } });
        dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'success', message: 'Files loaded successfully.' } });
      } catch (error: any) {
        dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'error', message: error.message } });
        dispatch({ type: 'SET_IMPORT_LOADING', payload: false });
      }
      if(fileInputRef.current) fileInputRef.current.value = '';
    }
  }, [dispatch]);
  
  const toggleNotifications = () => {
    if (!showNotifications) {
        dispatch({ type: 'MARK_NOTIFICATIONS_AS_READ' });
    }
    setShowNotifications(!showNotifications);
  };

  return (
    <header className="flex items-center justify-between p-3 bg-gray-100 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 shadow-sm flex-shrink-0 z-20">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2 text-accent-600 dark:text-accent-400">
          <span className="w-8 h-8">{ICONS.logo}</span>
          <h1 className="text-xl font-bold tracking-tight">RePDF</h1>
        </div>
        <div className="hidden md:flex items-center space-x-2">
          <button onClick={handleOpenClick} disabled={importLoading} className="flex items-center space-x-2 px-3 py-2 text-sm font-semibold rounded-md bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors disabled:opacity-50">
            {importLoading ? <span className="w-5 h-5">{ICONS.spinner}</span> : <span className="w-5 h-5">{ICONS.open}</span>}
            <span>{importLoading ? 'Loading...' : 'Open Files'}</span>
          </button>
          <input type="file" ref={fileInputRef} onChange={(e) => handleFileChange(e.target.files)} multiple accept=".pdf" className="hidden" />
          <button onClick={() => dispatch({type: 'SHOW_MODAL', payload: {type: 'export'}})} className="flex items-center space-x-2 px-3 py-2 text-sm font-semibold rounded-md bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 transition-colors">
            <span className="w-5 h-5">{ICONS.export}</span>
            <span>Export</span>
          </button>
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <button onClick={() => dispatch({ type: 'UNDO' })} disabled={past.length === 0} className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed">
            <span className="w-6 h-6">{ICONS.undo}</span>
        </button>
        <button onClick={() => dispatch({ type: 'REDO' })} disabled={future.length === 0} className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed">
            <span className="w-6 h-6">{ICONS.redo}</span>
        </button>
         <div className="relative">
            <button onClick={toggleNotifications} className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
                <span className="w-6 h-6">{ICONS.bell}</span>
                {unreadCount > 0 && <span className="absolute top-1 right-1 block h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-gray-100 dark:ring-gray-800" />}
            </button>
            {showNotifications && <NotificationsPopover notifications={notifications} onClear={() => dispatch({type: 'CLEAR_NOTIFICATIONS'})} onClose={() => setShowNotifications(false)} />}
         </div>
        <button onClick={() => dispatch({type: 'SHOW_MODAL', payload: {type: 'settings'}})} className="p-2 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700">
            <span className="w-6 h-6">{ICONS.settings}</span>
        </button>
      </div>
    </header>
  );
};


const FileTabsBar = () => {
    const { state, dispatch } = useAppContext();
    const { files, activeFileId } = state.undoableState.present;
    const { renameTargetId } = state.uiState;
    const [editingTabId, setEditingTabId] = useState<string|null>(null);
    const [tabName, setTabName] = useState('');
    const [dragOverTabId, setDragOverTabId] = useState<string | null>(null);
    const [dragOverPlus, setDragOverPlus] = useState(false);
    const hoverTimeoutRef = useRef<number | null>(null);
    const draggedItemIndex = useRef<number | null>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (renameTargetId) {
            const targetFile = files.find(f => f.id === renameTargetId);
            if (targetFile) {
                setEditingTabId(renameTargetId);
                setTabName(targetFile.name);
                dispatch({ type: 'SET_RENAME_TARGET', payload: null });
            }
        }
    }, [renameTargetId, files, dispatch]);

    useEffect(() => {
        if (editingTabId && inputRef.current) {
            inputRef.current.focus();
            inputRef.current.select();
        }
    }, [editingTabId]);

    const handleDoubleClick = (fileId: string, currentName: string) => {
        setEditingTabId(fileId);
        setTabName(currentName);
    };

    const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setTabName(e.target.value);
    };

    const handleNameSave = (fileId: string) => {
        if(tabName.trim()){
            dispatch({ type: 'RENAME_FILE', payload: { fileId, newName: tabName.trim() }});
        }
        setEditingTabId(null);
    };
    
    const handleDragLeave = () => {
        setDragOverTabId(null);
        setDragOverPlus(false);
        if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current);
            hoverTimeoutRef.current = null;
        }
    };

    const handleDragOver = (e: React.DragEvent, targetFileId: string | 'plus') => {
        e.preventDefault();
        
        if (e.dataTransfer.types.includes('application/json')) {
            e.dataTransfer.dropEffect = 'move';
            if (targetFileId === 'plus') {
                setDragOverPlus(true);
            } else {
                setDragOverTabId(targetFileId);
                if (hoverTimeoutRef.current === null && targetFileId !== activeFileId) {
                    hoverTimeoutRef.current = window.setTimeout(() => {
                        dispatch({ type: 'SET_ACTIVE_FILE', payload: targetFileId });
                    }, 700);
                }
            }
        } else if (e.dataTransfer.types.includes('text/plain') && e.dataTransfer.getData('text/plain').startsWith('file-tab-index:')) {
            e.dataTransfer.dropEffect = 'move';
            if (targetFileId !== 'plus') {
                setDragOverTabId(targetFileId);
            }
        }
    };

    const handleDropOnTab = (e: React.DragEvent, dropIndex: number, targetFileId: string) => {
        e.preventDefault();
        e.stopPropagation(); // Prevent grid drop handler from firing
    
        // Always clear hover effects
        handleDragLeave();
    
        // Check for page drop first
        const pagePayload = e.dataTransfer.getData("application/json");
        if (pagePayload && pagePayload.startsWith('{')) {
            try {
                const { sourceFileId, pageIds } = JSON.parse(pagePayload);
                if (sourceFileId !== targetFileId) {
                    const targetFile = files.find(f => f.id === targetFileId);
                    // When dropping on a tab, append pages to the end.
                    const finalDropIndex = targetFile ? targetFile.pageIds.length : 0;
                    dispatch({ type: 'SHOW_CONTEXTUAL_MENU', payload: { x: e.clientX, y: e.clientY, sourceFileId, targetFileId, pageIds, dropIndex: finalDropIndex }});
                }
                // If sourceFileId === targetFileId, do nothing (it's a no-op).
            } catch (error) {
                console.error("Error handling page drop on tab:", error);
            }
            return;
        }
    
        // Handle tab reordering
        const tabPayload = e.dataTransfer.getData('text/plain');
        if (tabPayload.startsWith('file-tab-index:')) {
            const startIndex = parseInt(tabPayload.split(':')[1], 10);
            if (startIndex !== dropIndex) {
                dispatch({ type: 'REORDER_FILES', payload: { startIndex, endIndex: dropIndex } });
            }
        }
        
        draggedItemIndex.current = null;
    };
    
    const handlePlusDrop = (e: React.DragEvent) => {
        e.preventDefault();
        const pageDragPayload = e.dataTransfer.getData("application/json");
        if (pageDragPayload && pageDragPayload.startsWith('{')) {
            try {
                const { sourceFileId, pageIds } = JSON.parse(pageDragPayload);
                dispatch({ type: 'MOVE_PAGES_TO_NEW_FILE', payload: { sourceFileId, pageIds } });
            } catch (error) {
                console.error("Error parsing page drop data on plus button:", error);
            }
        }
        handleDragLeave();
    };

    const handleTabDragStart = (e: React.DragEvent, index: number) => {
        draggedItemIndex.current = index;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', `file-tab-index:${index}`);
    };

    const handleTabDragEnd = () => {
        draggedItemIndex.current = null;
        handleDragLeave();
    };

    return (
        <div className="flex-shrink-0 bg-gray-50 dark:bg-gray-800/50 border-b border-gray-200 dark:border-gray-700 p-1 flex items-center space-x-1 overflow-x-auto z-10">
            {files.map((file, index) => (
                <div key={file.id} 
                     draggable
                     onDragStart={(e) => handleTabDragStart(e, index)}
                     onDragOver={(e) => handleDragOver(e, file.id)}
                     onDrop={(e) => handleDropOnTab(e, index, file.id)}
                     onDragEnd={handleTabDragEnd}
                     onDragLeave={handleDragLeave}
                     onClick={() => dispatch({ type: 'SET_ACTIVE_FILE', payload: file.id })}
                     onDoubleClick={() => handleDoubleClick(file.id, file.name)}
                     className={`flex items-center space-x-2 px-3 py-1.5 rounded-md cursor-pointer whitespace-nowrap text-sm transition-all duration-200 relative ${activeFileId === file.id ? 'bg-accent-100 dark:bg-accent-900/50 text-accent-700 dark:text-accent-200 font-semibold' : 'hover:bg-gray-200 dark:hover:bg-gray-700'} ${dragOverTabId === file.id ? 'scale-105 ring-2 ring-accent-500' : ''}`}>
                    
                    {editingTabId === file.id ? (
                        <input
                            ref={inputRef}
                            type="text"
                            value={tabName}
                            onChange={handleNameChange}
                            onBlur={() => handleNameSave(file.id)}
                            onKeyDown={(e) => e.key === 'Enter' && handleNameSave(file.id)}
                            className="bg-transparent focus:outline-none p-0 m-0 w-32"
                            onClick={e => e.stopPropagation()}
                        />
                    ) : (
                        <span>{file.name}</span>
                    )}
                    <button onClick={(e) => {e.stopPropagation(); dispatch({ type: 'CLOSE_FILE', payload: file.id })}} className="w-5 h-5 p-0.5 rounded-full hover:bg-gray-300 dark:hover:bg-gray-600"><span className="w-4 h-4">{ICONS.close}</span></button>
                </div>
            ))}
             <button
                onClick={() => dispatch({type: 'CREATE_EMPTY_FILE'})}
                onDragOver={(e) => handleDragOver(e, 'plus')}
                onDrop={handlePlusDrop}
                onDragLeave={handleDragLeave}
                title="Create a new, empty document"
                className={`flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-md text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all duration-200 ${dragOverPlus ? 'scale-110 ring-2 ring-accent-500 bg-accent-100 dark:bg-accent-900' : ''}`}
            >
                <span className="w-5 h-5">{ICONS.plus}</span>
            </button>
        </div>
    );
};


const ViewControlsToolbar = () => {
    const { state, dispatch } = useAppContext();
    const { activeFileId, selectedPageIds, pages, loadedDocs, files } = state.undoableState.present;
    const selectionCount = activeFileId ? (selectedPageIds[activeFileId]?.size || 0) : 0;
    
    const handleOCR = useCallback(async () => {
        if (!activeFileId || selectionCount === 0) return;
        const pageIds = Array.from(selectedPageIds[activeFileId]!);
        dispatch({ type: 'START_OCR', payload: { pageIds } });
        dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'info', message: `Starting OCR for ${pageIds.length} page(s).` } });

        for (const pageId of pageIds) {
            try {
                const pageInfo = pages[pageId];
                const doc = loadedDocs[pageInfo.sourceDocId];
                const base64Image = await getPageAsBase64(doc, pageInfo);
                const text = await runClientOcr(base64Image, dispatch);
                dispatch({ type: 'FINISH_OCR', payload: { pageId, text } });
            } catch (error: any) {
                dispatch({ type: 'FINISH_OCR', payload: { pageId, error: true } });
                dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'error', message: `OCR failed for one page: ${error.message}` } });
            }
        }
    }, [activeFileId, selectionCount, selectedPageIds, pages, loadedDocs, dispatch]);

    const handlePreview = () => {
        const activeFile = files.find(f => f.id === activeFileId);
        if (!activeFile) return;

        const currentSelection = selectedPageIds[activeFileId] || new Set();
        let pageIdsToPreview: string[];
        let startIndex = 0;

        if (currentSelection.size >= 2) {
            pageIdsToPreview = activeFile.pageIds.filter(id => currentSelection.has(id));
        } else {
            pageIdsToPreview = activeFile.pageIds;
        }

        if (pageIdsToPreview.length > 0) {
            dispatch({ type: 'SHOW_MODAL', payload: { type: 'quick-preview', modalPayload: { pageIds: pageIdsToPreview, startIndex } } });
        }
    };

    return (
        <div className="flex-shrink-0 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 p-2 flex items-center justify-between z-10">
            <div className="flex items-center space-x-2">
                 <button disabled={!activeFileId} onClick={handlePreview} title="Quick Preview" className="flex items-center space-x-1 px-2 py-1 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-50">
                    <span className="w-5 h-5">{ICONS.preview}</span><span>Preview</span>
                </button>
                <button disabled={selectionCount === 0} onClick={() => dispatch({ type: 'ROTATE_SELECTED_PAGES', payload: -90 })} title="Rotate Left" className="flex items-center space-x-1 px-2 py-1 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-50">
                    <span className="w-5 h-5">{ICONS.rotateLeft}</span><span>Rotate Left</span>
                </button>
                 <button disabled={selectionCount === 0} onClick={() => dispatch({ type: 'ROTATE_SELECTED_PAGES', payload: 90 })} title="Rotate Right" className="flex items-center space-x-1 px-2 py-1 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-50">
                    <span className="w-5 h-5">{ICONS.rotateRight}</span><span>Rotate Right</span>
                </button>
                <button disabled={selectionCount === 0} onClick={() => dispatch({ type: 'DELETE_SELECTED_PAGES' })} className="flex items-center space-x-1 px-2 py-1 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-50">
                    <span className="w-5 h-5">{ICONS.delete}</span><span>Delete</span>
                </button>
                <button disabled={selectionCount === 0} onClick={handleOCR} className="flex items-center space-x-1 px-2 py-1 text-sm rounded-md hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-50">
                    <span className="w-5 h-5">{ICONS.ocr}</span><span>Make Searchable (OCR)</span>
                </button>
            </div>
            <div className="text-sm text-gray-500">
                {selectionCount > 0 ? `${selectionCount} page(s) selected` : 'No pages selected'}
            </div>
        </div>
    );
};

const ContextualMenu = () => {
    const { state, dispatch } = useAppContext();
    const { contextualMenu } = state.uiState;
    
    if (!contextualMenu) return null;

    const { x, y, sourceFileId, targetFileId, pageIds, dropIndex } = contextualMenu;

    const handleMove = (copy: boolean) => {
        dispatch({ type: 'MOVE_PAGES_TO_FILE', payload: { sourceFileId, targetFileId, pageIds, copy, dropIndex }});
        dispatch({ type: 'HIDE_CONTEXTUAL_MENU' });
    }

    return (
        <div 
            className="fixed z-50 bg-white dark:bg-gray-800 shadow-2xl rounded-lg border border-gray-200 dark:border-gray-700 p-2 animate-modal-show flex flex-col space-y-1" 
            style={{ left: x, top: y }}
            onClick={(e) => e.stopPropagation()}
        >
            <button onClick={() => handleMove(true)} className="flex items-center space-x-2 text-left w-full px-3 py-1.5 rounded-md text-sm hover:bg-gray-100 dark:hover:bg-gray-700">
                <span className="w-5 h-5 text-gray-600 dark:text-gray-300">{ICONS.copy}</span>
                <span>Copy {pageIds.length} page(s)</span>
            </button>
            <button onClick={() => handleMove(false)} className="flex items-center space-x-2 text-left w-full px-3 py-1.5 rounded-md text-sm hover:bg-gray-100 dark:hover:bg-gray-700">
                 <span className="w-5 h-5 text-gray-600 dark:text-gray-300">{ICONS.move}</span>
                <span>Move {pageIds.length} page(s)</span>
            </button>
        </div>
    );
};

const App = () => {
  const { state, dispatch } = useAppContext();
  const { activeFileId, files, pages } = state.undoableState.present;

  const activeFile = files.find(f => f.id === activeFileId);
  const activeFilePages = activeFile ? activeFile.pageIds.map(id => pages[id]) : [];

  const handleFileDrop = useCallback(async (filesToLoad: FileList | null) => {
    if (filesToLoad && filesToLoad.length > 0) {
      dispatch({ type: 'SET_IMPORT_LOADING', payload: true });
      dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'info', message: `Loading ${filesToLoad.length} file(s)...` } });
      try {
        const { files, pages, loadedDocs } = await loadPdfFromFiles(Array.from(filesToLoad));
        dispatch({ type: 'ADD_FILES', payload: { files, pages, loadedDocs } });
        dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'success', message: 'Files loaded successfully.' } });
      } catch (error: any) {
        dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'error', message: error.message } });
        dispatch({ type: 'SET_IMPORT_LOADING', payload: false });
      }
    }
  }, [dispatch]);

  return (
    <div className="h-screen w-screen flex flex-col bg-white dark:bg-gray-900">
      <Header />
      <main className="flex-grow flex flex-col min-h-0">
        {files.length > 0 && <FileTabsBar />}
        {files.length > 0 && <ViewControlsToolbar />}
        <div className="flex-grow overflow-auto bg-gray-100/50 dark:bg-black/20">
            {activeFile ? (
                <PageGrid fileId={activeFile.id} pages={activeFilePages} />
            ) : (
                <EmptyWorkspace onFileDrop={handleFileDrop} />
            )}
        </div>
      </main>
      <ModalManager />
      <ContextualMenu />
    </div>
  );
};

export default App;
import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../context/AppContext';
import { ICONS } from '../constants';
import { AccentColor, Theme, QuickPreviewPayload, PageInfo } from '../types';
import { exportPdf, renderHighResPage } from '../services/pdfService';

const DraggableResizableModal = ({ title, children, isFullScreen, onClose, initialSize = { width: 640, height: 400 } }: { title: string, children: React.ReactNode, isFullScreen?: boolean, onClose: () => void, initialSize?: {width: number, height: number} }) => {
    const { state } = useAppContext();
    const [position, setPosition] = useState({ x: window.innerWidth / 2 - initialSize.width / 2, y: window.innerHeight / 2 - initialSize.height / 2 });
    const [size, setSize] = useState(initialSize);
    const [isDragging, setIsDragging] = useState(false);
    const [isResizing, setIsResizing] = useState(false);
    const dragStartPos = useRef({ x: 0, y: 0 });
    const resizeStartSize = useRef({ width: 0, height: 0});

    const handleMouseDownDrag = (e: React.MouseEvent<HTMLDivElement>) => {
        if((e.target as HTMLElement).closest('button, input')) return;
        setIsDragging(true);
        dragStartPos.current = { x: e.clientX - position.x, y: e.clientY - position.y };
    };
    
    const handleMouseDownResize = (e: React.MouseEvent<HTMLDivElement>) => {
        e.stopPropagation();
        setIsResizing(true);
        dragStartPos.current = { x: e.clientX, y: e.clientY };
        resizeStartSize.current = size;
    };

    const handleMouseMove = (e: MouseEvent) => {
        if (isDragging) {
            setPosition({
                x: e.clientX - dragStartPos.current.x,
                y: e.clientY - dragStartPos.current.y
            });
        }
        if (isResizing) {
            const dx = e.clientX - dragStartPos.current.x;
            const dy = e.clientY - dragStartPos.current.y;
            setSize({
                width: Math.max(400, resizeStartSize.current.width + dx),
                height: Math.max(300, resizeStartSize.current.height + dy)
            });
        }
    };

    const handleMouseUp = () => {
        setIsDragging(false);
        setIsResizing(false);
    };

    useEffect(() => {
        if (isDragging || isResizing) {
            window.addEventListener('mousemove', handleMouseMove);
            window.addEventListener('mouseup', handleMouseUp);
        }
        return () => {
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseup', handleMouseUp);
        };
    }, [isDragging, isResizing]);
    
    if (isFullScreen) {
      return <>{children}</>;
    }

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-center justify-center" onClick={onClose}>
            <div 
                className="bg-white dark:bg-gray-800 rounded-lg shadow-2xl flex flex-col overflow-hidden animate-modal-show" 
                style={{ transform: `translate(${position.x}px, ${position.y}px)`, width: size.width, height: size.height }}
                onClick={e => e.stopPropagation()}
            >
                <div 
                    className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700 cursor-move"
                    onMouseDown={handleMouseDownDrag}
                >
                    <h2 className="text-lg font-semibold select-none">{title}</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors z-10">
                        <span className="w-6 h-6">{ICONS.close}</span>
                    </button>
                </div>
                <div className="p-6 flex-grow overflow-auto">
                    {children}
                </div>
                <div 
                    className="absolute bottom-0 right-0 w-4 h-4 cursor-se-resize text-gray-400 dark:text-gray-600"
                    onMouseDown={handleMouseDownResize}
                >
                    <svg className="w-full h-full" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 20L20 12" /></svg>
                </div>
            </div>
        </div>
    );
};


const ModalManager = () => {
  const { state, dispatch } = useAppContext();
  const { activeModal, modalPayload } = state.uiState;

  if (!activeModal) return null;

  const closeModal = () => dispatch({ type: 'HIDE_MODAL' });

  let modalContent: React.ReactNode;
  let modalTitle = "";
  let isFullScreen = false;
  let modalSize = { width: 500, height: 480 };

  switch (activeModal) {
    case 'settings':
      modalTitle = "Settings";
      modalContent = <SettingsModal />;
      modalSize = { width: 400, height: 350 };
      break;
    case 'export':
        modalTitle = "Export Documents";
        modalContent = <ExportModal />;
        modalSize = { width: 500, height: 580 };
        break;
    case 'quick-preview':
        isFullScreen = true;
        modalContent = <QuickPreviewModal payload={modalPayload as QuickPreviewPayload} onClose={closeModal} />;
        break;
    default:
      return null;
  }
  
  return (
    <DraggableResizableModal title={modalTitle} isFullScreen={isFullScreen} onClose={closeModal} initialSize={modalSize}>
        {modalContent}
    </DraggableResizableModal>
  );
};

const QuickPreviewModal = ({ payload, onClose }: { payload: QuickPreviewPayload, onClose: () => void }) => {
    const { state } = useAppContext();
    const { pages, loadedDocs } = state.undoableState.present;
    const [currentIndex, setCurrentIndex] = useState(payload.startIndex);
    const [isLoading, setIsLoading] = useState(true);
    const [magnifierStyle, setMagnifierStyle] = useState<React.CSSProperties>({ display: 'none' });
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [isFading, setIsFading] = useState(false);

    const pageInfo = pages[payload.pageIds[currentIndex]];
    const loadedDoc = loadedDocs[pageInfo.sourceDocId];

    const navigate = (direction: number) => {
        setIsFading(true);
        setTimeout(() => {
            const newIndex = (currentIndex + direction + payload.pageIds.length) % payload.pageIds.length;
            setCurrentIndex(newIndex);
        }, 150);
    };

    useEffect(() => {
        const handleKeyDown = (e: KeyboardEvent) => {
            if (e.key === 'ArrowRight') navigate(1);
            else if (e.key === 'ArrowLeft') navigate(-1);
            else if (e.key === 'Escape') onClose();
        };
        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [currentIndex, payload.pageIds.length]);

    useEffect(() => {
        let isMounted = true;
        if (canvasRef.current && loadedDoc) {
            setIsLoading(true);
            renderHighResPage(loadedDoc, pageInfo, canvasRef.current)
                .then(() => { 
                    if (isMounted) {
                        setIsLoading(false); 
                        setIsFading(false);
                    }
                })
                .catch(console.error);
        }
        return () => { isMounted = false; };
    }, [pageInfo, loadedDoc]);
    
    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        const target = e.currentTarget;
        const canvas = canvasRef.current;
        if (!canvas || isLoading) return;
        const rect = target.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const backgroundX = -(x / target.offsetWidth * canvas.width - 100);
        const backgroundY = -(y / target.offsetHeight * canvas.height - 100);

        setMagnifierStyle({
            display: 'block',
            top: `${e.clientY - 100}px`,
            left: `${e.clientX - 100}px`,
            backgroundImage: `url(${canvas.toDataURL()})`,
            backgroundPosition: `${backgroundX}px ${backgroundY}px`,
            backgroundSize: `${canvas.width}px ${canvas.height}px`,
        });
    };

    return (
        <>
        <div className="fixed inset-0 bg-gray-900/80 backdrop-blur-lg z-50 flex flex-col animate-modal-show" onClick={onClose}>
            <header className="flex-shrink-0 flex items-center justify-between p-4 text-white">
                <div className="font-semibold">
                    Page {pages[payload.pageIds[currentIndex]].sourcePageIndex + 1}
                    <span className="text-gray-400 font-normal"> of {loadedDoc.fileName}</span>
                </div>
                 <div className="flex items-center space-x-4">
                    <span className="text-sm text-gray-300">
                      {currentIndex + 1} / {payload.pageIds.length}
                    </span>
                    <button onClick={onClose} className="text-gray-300 hover:text-white transition-colors">
                        <span className="w-8 h-8">{ICONS.close}</span>
                    </button>
                </div>
            </header>
            <main className="flex-grow flex items-center justify-center p-8 min-h-0 relative">
                {isLoading && <span className="w-12 h-12 text-white absolute">{ICONS.spinner}</span>}
                <div 
                    className={`relative transition-opacity duration-150 ${isLoading || isFading ? 'opacity-0' : 'opacity-100'}`}
                    onMouseMove={handleMouseMove}
                    onMouseLeave={() => setMagnifierStyle({ display: 'none' })}
                >
                    <canvas ref={canvasRef} className="max-w-full max-h-full h-auto w-auto object-contain shadow-2xl rounded-md" />
                     <div className="absolute inset-0 grid grid-cols-2">
                        <div className="cursor-w-resize" onClick={(e) => { e.stopPropagation(); navigate(-1); }}></div>
                        <div className="cursor-e-resize" onClick={(e) => { e.stopPropagation(); navigate(1); }}></div>
                    </div>
                </div>
            </main>
            <footer className="flex-shrink-0 flex items-center justify-center p-4 space-x-4">
                <button onClick={() => navigate(-1)} className="p-3 rounded-full bg-black/30 text-white hover:bg-black/50 disabled:opacity-50 disabled:cursor-not-allowed">
                     <span className="w-6 h-6 transform rotate-180">{ICONS.redo}</span>
                </button>
                <button onClick={() => navigate(1)} className="p-3 rounded-full bg-black/30 text-white hover:bg-black/50 disabled:opacity-50 disabled:cursor-not-allowed">
                     <span className="w-6 h-6">{ICONS.redo}</span>
                </button>
            </footer>
        </div>
        <div 
            className="fixed pointer-events-none w-52 h-52 rounded-full border-4 border-accent-500 bg-white shadow-xl"
            style={magnifierStyle}
        ></div>
        </>
    );
};

const SettingsModal = () => {
    const { state, dispatch } = useAppContext();
    const { theme, accentColor } = state.uiState;

    const handleThemeChange = (newTheme: Theme) => {
        dispatch({ type: 'SET_THEME', payload: newTheme });
    };

    const handleAccentChange = (newAccent: AccentColor) => {
        dispatch({ type: 'SET_ACCENT_COLOR', payload: newAccent });
    };

    useEffect(() => {
        document.documentElement.className = theme;
    }, [theme]);
    
    useEffect(() => {
        const root = document.documentElement;
        const hex = accentColor.hex;
        if (!/^#([0-9A-F]{3}){1,2}$/i.test(hex)) return;

        let r: number, g: number, b: number;
        if (hex.length === 4) {
            r = parseInt(hex[1] + hex[1], 16);
            g = parseInt(hex[2] + hex[2], 16);
            b = parseInt(hex[3] + hex[3], 16);
        } else {
            r = parseInt(hex.slice(1, 3), 16);
            g = parseInt(hex.slice(3, 5), 16);
            b = parseInt(hex.slice(5, 7), 16);
        }
        
        for(let i=0; i <= 20; i++) {
            const shade = 50 * i;
            const ratio = i / 10 - 1; // from -1 to 1
            const mix = (c: number, t: number) => Math.round(t > 0 ? c * (1-t) + 255 * t : c * (1+t));
            
            const r_adj = mix(r, theme === Theme.LIGHT ? ratio * -0.8 : ratio * 0.8);
            const g_adj = mix(g, theme === Theme.LIGHT ? ratio * -0.8 : ratio * 0.8);
            const b_adj = mix(b, theme === Theme.LIGHT ? ratio * -0.8 : ratio * 0.8);
            
            if(shade <= 950)
                root.style.setProperty(`--accent-color-${shade}`, `${r_adj}, ${g_adj}, ${b_adj}`);
        }

        const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
        root.style.setProperty('--accent-color-contrast', luminance > 0.5 ? 'black' : 'white');
        root.style.setProperty('--accent-color-500', `${r}, ${g}, ${b}`);
    }, [accentColor, theme]);


    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-md font-medium mb-2">Theme</h3>
                <div className="flex space-x-2">
                    <button onClick={() => handleThemeChange(Theme.LIGHT)} className={`px-4 py-2 rounded-md text-sm font-semibold ${theme === Theme.LIGHT ? 'bg-accent-600 text-accent-contrast' : 'bg-gray-200 dark:bg-gray-700'}`}>Light</button>
                    <button onClick={() => handleThemeChange(Theme.DARK)} className={`px-4 py-2 rounded-md text-sm font-semibold ${theme === Theme.DARK ? 'bg-accent-600 text-accent-contrast' : 'bg-gray-200 dark:bg-gray-700'}`}>Dark</button>
                </div>
            </div>
            <div>
                <h3 className="text-md font-medium mb-2">Accent Color</h3>
                <div className="flex items-center gap-2">
                    <input 
                        type="color" 
                        value={accentColor.hex}
                        onChange={(e) => handleAccentChange({ name: 'Custom', hex: e.target.value })}
                        className="w-12 h-12 p-0 border-none rounded-md bg-transparent cursor-pointer"
                        style={{'--webkit-appearance': 'none'} as React.CSSProperties}
                    />
                    <span className="text-sm text-gray-600 dark:text-gray-300">Choose any color you like.</span>
                </div>
            </div>
        </div>
    );
};

const ExportModal = () => {
    const { state, dispatch } = useAppContext();
    const { files, pages, loadedDocs } = state.undoableState.present;
    const [selectedFiles, setSelectedFiles] = useState<Record<string, boolean>>({});
    const [combine, setCombine] = useState(true);
    const [password, setPassword] = useState('');
    const [split, setSplit] = useState(false);
    const [splitSize, setSplitSize] = useState(40);
    const [isExporting, setIsExporting] = useState(false);

    useEffect(() => {
        setSelectedFiles(files.reduce((acc, file) => ({...acc, [file.id]: true}), {}));
    }, [files]);

    const handleExport = async () => {
        setIsExporting(true);
        dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'info', message: 'Starting export...' } });
        try {
            const filesToExport = files.filter(f => selectedFiles[f.id]);
            await exportPdf(filesToExport, pages, loadedDocs, { combine, password, split, splitSizeMB: splitSize });
            dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'success', message: 'Export completed successfully!' } });
        } catch (e: any) {
            console.error(e);
            dispatch({ type: 'ADD_NOTIFICATION', payload: { type: 'error', message: `Export failed: ${e.message}` } });
        } finally {
            setIsExporting(false);
            dispatch({ type: 'HIDE_MODAL' });
        }
    };
    
    return (
        <div className="space-y-6">
            <div>
                <h3 className="text-md font-medium mb-2">Files to Export</h3>
                <div className="space-y-2 max-h-40 overflow-y-auto border border-gray-200 dark:border-gray-700 rounded-md p-2">
                    {files.map(file => (
                        <label key={file.id} className="flex items-center space-x-2 cursor-pointer p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700/50">
                            <input type="checkbox" checked={selectedFiles[file.id] || false} onChange={e => setSelectedFiles({...selectedFiles, [file.id]: e.target.checked})} className="h-4 w-4 rounded text-accent-600 border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-900 focus:ring-accent-500" />
                            <span>{file.name}</span>
                        </label>
                    ))}
                </div>
            </div>
             <div>
                <h3 className="text-md font-medium mb-2">Export Mode</h3>
                 <div className="flex space-x-2">
                    <button onClick={() => setCombine(true)} className={`px-4 py-2 rounded-md text-sm font-semibold ${combine ? 'bg-accent-600 text-accent-contrast' : 'bg-gray-200 dark:bg-gray-700'}`}>Combine</button>
                    <button onClick={() => setCombine(false)} className={`px-4 py-2 rounded-md text-sm font-semibold ${!combine ? 'bg-accent-600 text-accent-contrast' : 'bg-gray-200 dark:bg-gray-700'}`}>Separate</button>
                </div>
            </div>
             <div className="space-y-4">
                <h3 className="text-md font-medium mb-2 border-t pt-4 border-gray-200 dark:border-gray-700">Advanced Options</h3>
                <div>
                    <label className="text-sm font-medium">Password (Optional)</label>
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter password to encrypt" className="w-full mt-1 px-3 py-2 bg-gray-100 dark:bg-gray-700 rounded-md border border-transparent focus:ring-2 focus:ring-accent-500 focus:border-transparent"/>
                </div>
                {combine && (
                    <div>
                        <label className="flex items-center space-x-2 cursor-pointer">
                            <input type="checkbox" checked={split} onChange={e => setSplit(e.target.checked)} className="h-4 w-4 rounded text-accent-600 border-gray-300 dark:border-gray-600 bg-gray-100 dark:bg-gray-900 focus:ring-accent-500"/>
                            <span>Auto-split combined file</span>
                        </label>
                        {split && (
                            <div className="flex items-center space-x-2 mt-2 pl-6">
                                <span className="text-sm">if larger than</span>
                                <input type="number" value={splitSize} onChange={e => setSplitSize(Number(e.target.value))} className="w-20 px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded-md border border-transparent focus:ring-2 focus:ring-accent-500 focus:border-transparent"/>
                                <span className="text-sm">MB</span>
                            </div>
                        )}
                    </div>
                )}
            </div>
            <div className="flex justify-end pt-4">
                 <button onClick={handleExport} disabled={isExporting} className="px-6 py-2 rounded-md text-sm font-semibold bg-accent-600 text-accent-contrast hover:bg-accent-700 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center">
                    {isExporting && <span className="w-4 h-4 mr-2">{ICONS.spinner}</span>}
                    {isExporting ? 'Exporting...' : 'Export'}
                </button>
            </div>
        </div>
    );
};


export default ModalManager;
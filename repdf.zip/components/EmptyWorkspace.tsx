import React, { useState, useCallback } from 'react';
import { ICONS } from '../constants';

interface EmptyWorkspaceProps {
    onFileDrop: (files: FileList) => void;
}

const EmptyWorkspace = ({ onFileDrop }: EmptyWorkspaceProps) => {
    const [isDragOver, setIsDragOver] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleOpenClick = () => fileInputRef.current?.click();

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            onFileDrop(event.target.files);
        }
    };
    
    const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragOver(true);
    }, []);

    const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragOver(false);
    }, []);

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragOver(false);
        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            onFileDrop(e.dataTransfer.files);
        }
    }, [onFileDrop]);

    const shortcuts = [
        { keys: 'Ctrl/Cmd + Click', desc: 'Select multiple pages' },
        { keys: 'Shift + Click', desc: 'Select a range of pages' },
        { keys: 'Double Click Tab', desc: 'Rename document' },
        { keys: 'Drag & Drop Pages', desc: 'Reorder or move to another file' },
        { keys: 'Drag & Drop Tabs', desc: 'Reorder documents for export' },
        { keys: 'Esc', desc: 'Close modals & menus' },
    ];

    return (
        <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`h-full w-full flex flex-col items-center justify-center p-8 transition-colors ${isDragOver ? 'bg-accent-500/10' : ''}`}
        >
            <div className={`w-full max-w-4xl h-full border-2 border-dashed ${isDragOver ? 'border-accent-500' : 'border-gray-300 dark:border-gray-600'} rounded-2xl flex flex-col items-center justify-center text-center p-8`}>
                <span className={`w-24 h-24 mb-4 text-gray-300 dark:text-gray-600 transition-colors ${isDragOver ? 'text-accent-500' : ''}`}>{ICONS.logo}</span>
                <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-200">Welcome to RePDF</h2>
                <p className="mt-2 text-lg text-gray-500 dark:text-gray-400">Your private, powerful PDF workspace.</p>
                <div className="mt-8">
                    <button 
                        onClick={handleOpenClick}
                        className="px-8 py-4 bg-accent-600 text-accent-contrast font-semibold rounded-lg shadow-md hover:bg-accent-700 transition-all transform hover:scale-105"
                    >
                        Open Files
                    </button>
                    <input type="file" ref={fileInputRef} onChange={handleFileChange} multiple accept=".pdf" className="hidden" />
                    <p className="mt-4 text-gray-500">or drop them anywhere</p>
                </div>

                <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-700 w-full max-w-lg">
                    <h3 className="text-sm font-semibold uppercase text-gray-400 tracking-wider">Shortcuts</h3>
                    <dl className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2 text-left">
                        {shortcuts.map(sc => (
                             <div key={sc.keys} className="flex items-baseline">
                                <dt className="w-1/2 font-mono text-sm text-gray-600 dark:text-gray-300 pr-2">{sc.keys}</dt>
                                <dd className="w-1/2 text-sm text-gray-500 dark:text-gray-400">{sc.desc}</dd>
                            </div>
                        ))}
                    </dl>
                </div>
            </div>
        </div>
    );
};

export default EmptyWorkspace;
